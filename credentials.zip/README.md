
# Getting started with kubernetes

1. please refer to the official documentation for installing the kubectl client:

https://kubernetes.io/docs/tasks/tools/#kubectl


2. create a kraud context and cluster

	kubectl config set-cluster kraud.mountain7882 --server=https://k8s.m.kraudcloud.com --certificate-authority=ca.crt --embed-certs=true
	kubectl config set-context kraud.mountain7882 --cluster=kraud.mountain7882 --user=aungsanoo2056@gmail.com@mountain7882
	kubectl config set-credentials aungsanoo2056@gmail.com@mountain7882 --client-key=key.pem --client-certificate=cert.pem --embed-certs=true
	kubectl config use-context kraud.mountain7882

3. test the kubectl client

	$ kubectl get pods
	No resources found in default namespace.


4. configure the docker cli

	mkdir -p ~/.docker/contexts/tls/kraud.mountain7882
	cp ca.crt ~/.docker/contexts/tls/kraud.mountain7882/ca.crt
	cp key.pem ~/.docker/contexts/tls/kraud.mountain7882/key.pem
	cp cert.pem ~/.docker/contexts/tls/kraud.mountain7882/cert.pem
	docker context create kraud.mountain7882 --docker host=tcp://docker.m.kraudcloud.com:443,cert=$HOME/.docker/contexts/tls/kraud.mountain7882/cert.pem,key=$HOME/.docker/contexts/tls/kraud.mountain7882/key.pem,ca=$HOME/.docker/contexts/tls/kraud.mountain7882/ca.crt

5. test the docker client

	docker --context kraud.mountain7882 ps

